# HST v4 Unified Training Script - Token & Chunk Processing Modes
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn
import numpy as np
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

for pkg in ["torch", "numpy", "tqdm", "scikit-learn"]:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", pkg])

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
os.makedirs('/content/drive/MyDrive/HST_Training/v4_models', exist_ok=True)

print(f"HST v4 Unified Training - Device: {device}")

class ChunkEncoder(nn.Module):
    def __init__(self, feature_dim, chunk_size=10):
        super().__init__()
        self.chunk_size = chunk_size
        self.encoder = nn.Linear(feature_dim * chunk_size, feature_dim)
    
    def forward(self, x):
        return self.encoder(x)

class ChunkDecoder(nn.Module):
    def __init__(self, feature_dim, chunk_size=10):
        super().__init__()
        self.chunk_size = chunk_size
        self.decoder = nn.Linear(feature_dim, feature_dim * chunk_size)
    
    def forward(self, x):
        return self.decoder(x)

class HSTv4(nn.Module):
    def __init__(self, feature_dim=32, num_layers=4):
        super().__init__()
        self.input_proj = nn.Linear(1, feature_dim)
        self.chunk_encoder = ChunkEncoder(feature_dim, 10)
        self.chunk_decoder = ChunkDecoder(feature_dim, 10)
        self.layers = nn.ModuleList([nn.Linear(feature_dim, feature_dim) for _ in range(num_layers)])
        self.output_proj = nn.Linear(feature_dim, 1)
    
    def forward(self, x):
        if len(x.shape) == 2:
            x = x.unsqueeze(-1)
        x = self.input_proj(x)
        for layer in self.layers:
            x = nn.ReLU()(layer(x))
        return self.output_proj(x)

def create_data(n_samples=1000, seq_len=100):
    data = np.array([np.linspace(0, 5, seq_len) + 2 * np.sin(2 * np.pi * np.arange(seq_len) / 50) + np.random.normal(0, 0.5, seq_len) for _ in range(n_samples)])
    scaler = StandardScaler()
    data = scaler.fit_transform(data.reshape(-1, 1)).reshape(data.shape)
    return data, scaler

train_data, scaler = create_data()
train_size = int(0.8 * len(train_data))
train_loader = DataLoader(TensorDataset(torch.FloatTensor(train_data[:train_size]).to(device)), batch_size=32, shuffle=True)
val_loader = DataLoader(TensorDataset(torch.FloatTensor(train_data[train_size:]).to(device)), batch_size=32)

model = HSTv4().to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
criterion = nn.MSELoss()

for epoch in range(10):
    model.train()
    train_loss = sum((optimizer.zero_grad(), loss := criterion(model(X)[:, :-1], X[:, 1:]), optimizer.backward(loss) if (optimizer.step(), True) else False, loss.item())[-1] for X, in train_loader) / len(train_loader)
    model.eval()
    val_loss = sum(criterion(model(X)[:, :-1], X[:, 1:]).item() for X, in val_loader) / len(val_loader)
    print(f"Epoch {epoch+1}: Train={train_loss:.6f}, Val={val_loss:.6f}")

torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v4_models/hst_v4_trained.pt')
print("✓ HST v4 model saved")
