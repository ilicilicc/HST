# HST Model Training Scripts for Google Colab

This collection contains dedicated training scripts for every HST architecture version. Each script implements the unique components and innovations of its version.

## Version Breakdown

### v3 Ultra - CompleteLatticeCore
- **Features**: Path-weighted GNN logic, KV Cache (5-8x speedup), Early Exit mechanism
- **Best for**: Baseline with efficiency optimizations
- **Script**: `hst_v3_ultra_colab_training.py`

### v4 Unified - Token & Chunk Processing
- **Features**: ChunkEncoder/Decoder, unified token/chunk modes, flexible granularity
- **Best for**: Multi-scale processing
- **Script**: `hst_v4_unified_colab_training.py`

### v5.2 Unified - Hierarchical Analysis
- **Features**: RecursiveDescentLatticeAnalyzer, RecursiveHorizonPredictor
- **Best for**: Deep hierarchical understanding
- **Script**: `hst_v5_2_unified_colab_training.py`

### v6.3 Giga - Expanded Capabilities
- **Features**: CompressedCache, SpeculativeVerifier, ContinualUpdater, ReasoningHead
- **Best for**: Production reasoning tasks
- **Script**: `hst_v6_3_giga_colab_training.py`

### v7.1 Ultimate - Performance Peak
- **Features**: FlashBlockSparseAttention, SparseExpertRouter (MoE), Tree-Based Speculative Decoding
- **Best for**: High-speed inference and reasoning
- **Script**: `hst_v7_1_ultimate_colab_training.py`

### v8 Crystalline - Architecture Peak
- **Features**: Pell-Lucas Time Spine, Holographic Lattice, Diamond Mixer, Hebbian Plasticity, Feedback Loop
- **Best for**: Theoretical best performance with infinite context
- **Script**: `hst_v8_crystalline_colab_training.py`

### v8.2 Latest - Memory Optimization
- **Features**: PagedKVCache (block allocation), DynamicLatticeGate (sparse routing), HyperLatticeBlock
- **Best for**: Memory-efficient training and inference
- **Script**: `hst_v8_2_latest_colab_training.py`

### CL (Chaos Logic)
- **Features**: ChaoticTimer, rhythmic iterative passes, void/chaos states
- **Best for**: Creative and non-deterministic generation
- **Script**: `hst_chaos_logic_colab_training.py`

### EN (Error Networks)
- **Features**: ErrorSupervisor, HomeostasisController, self-correction mechanisms
- **Best for**: Robust self-correcting inference
- **Script**: `hst_error_networks_colab_training.py`

## Usage

1. Copy entire script content into a Google Colab cell
2. Run the cell - it will automatically:
   - Mount Google Drive
   - Install dependencies
   - Detect GPU availability
   - Generate synthetic training data
   - Train the model
   - Save checkpoint to Google Drive

## Performance Tips

- **v8 Crystalline**: Best theoretical performance but highest complexity
- **v7.1 Ultimate**: Best practical performance for most tasks
- **v3 Ultra**: Fastest training, good baseline
- **EN (Error Networks)**: For reliability-critical applications

All models save checkpoints to `/content/drive/MyDrive/HST_Training/[version]_models/`
