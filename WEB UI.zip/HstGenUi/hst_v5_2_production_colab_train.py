from google.colab import drive; drive.mount('/content/drive')
import torch, torch.nn as nn, torch.nn.functional as F
from transformers import AutoTokenizer, get_linear_schedule_with_warmup, DataCollatorForLanguageModeling
from datasets import load_dataset
from torch.utils.data import DataLoader
import os; os.makedirs('/content/drive/MyDrive/HST_Training/v5_2_production_scaled', exist_ok=True)
device = torch.device('cuda'); print("HST v5_2 - PRODUCTION SCALED (768-dim, 12 layers, 1024 context, Wikitext-103)")
os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2"); tokenizer.pad_token = tokenizer.eos_token

class TransformerBlock(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True)
        self.ffn = nn.Sequential(nn.Linear(d_model, d_model*4), nn.GELU(), nn.Linear(d_model*4, d_model))
        self.norm1 = nn.LayerNorm(d_model); self.norm2 = nn.LayerNorm(d_model)
    def forward(self, x):
        x = x + self.attn(self.norm1(x), self.norm1(x), self.norm1(x))[0]
        x = x + self.ffn(self.norm2(x))
        return x

class HSTv5_2Scaled(nn.Module):
    def __init__(self, vocab_size=50257, d_model=768, num_layers=12, n_heads=12):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(2048, d_model)
        self.blocks = nn.ModuleList([TransformerBlock(d_model, n_heads) for _ in range(num_layers)])
        self.ln_f = nn.LayerNorm(d_model)
        self.output_proj = nn.Linear(d_model, vocab_size, bias=False)
        self.output_proj.weight = self.embed.weight
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        for block in self.blocks: x = block(x)
        x = self.ln_f(x)
        return self.output_proj(x)

dataset = load_dataset("wikitext", "wikitext-103-v1", split="train")
tokenized = dataset.map(lambda x: tokenizer(x["text"], max_length=1024, truncation=True), batched=True, remove_columns=["text"])
tokenized.set_format('torch', columns=['input_ids'])

data_collator = DataCollatorForLanguageModeling(tokenizer, mlm=False)
dataloader = DataLoader(tokenized, batch_size=8, shuffle=True, collate_fn=data_collator)

model = HSTv5_2Scaled(vocab_size=50257, d_model=768, num_layers=12, n_heads=12).to(device)
opt = torch.optim.AdamW(model.parameters(), lr=8e-4, weight_decay=0.1, betas=(0.9, 0.95))
scheduler = get_linear_schedule_with_warmup(opt, num_warmup_steps=3000, num_training_steps=100000)

for step, batch in enumerate(dataloader):
    if step >= 100000: break
    input_ids = batch["input_ids"].to(device)
    logits = model(input_ids)
    loss = F.cross_entropy(logits.view(-1, logits.size(-1)), input_ids.view(-1))
    loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    opt.step(); scheduler.step(); opt.zero_grad()
    if step % 500 == 0: print(f"Step {step} | Loss {loss.item():.4f}")

torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v5_2_production_scaled/hst_v5_2_production_scaled.pt')
print("✓ HST v5_2 SCALED Production Trained (768-dim, 12 layers, 1024 context, Wikitext-103)")
