# HST v3 Ultra - Hugging Face Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn, torch.nn.functional as F
# torch transformers datasets pre-installed in Colab
import numpy as np
from transformers import AutoTokenizer, get_linear_schedule_with_warmup
from datasets import load_dataset
from torch.utils.data import DataLoader, IterableDataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v3_hf', exist_ok=True)
print("HST v3 Ultra - HF Language Dataset Training")

os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

class FullLatticeFieldAnalyzer(nn.Module):
    def __init__(self, max_seq_len=512):
        super().__init__()
        spine = [0, 2, 4]
        while spine[-1] < max_seq_len:
            spine.append(2*spine[-1] + spine[-2] if len(spine)>1 else 0)
        self.register_buffer('spine', torch.tensor(spine[:min(len(spine), 10)], dtype=torch.long))
    
    def _analyze_position(self, pos):
        levels = {0: [pos]}
        visited = {pos}
        current_level = [pos]
        level = 0
        while current_level and level < 10:
            next_level = set()
            for node in current_level:
                for s in self.spine:
                    if s < node and s not in visited: 
                        visited.add(s); next_level.add(s)
            current_level = list(next_level)
            level += 1
            if current_level: levels[level] = current_level.copy()
        return {'levels': levels, 'total_ancestors': len(visited)-1, 'max_depth': max(levels.keys()) if levels else 0}

class PathWeightedLatticeCore(nn.Module):
    def __init__(self, d_model, max_seq_len=512):
        super().__init__()
        self.analyzer = FullLatticeFieldAnalyzer(max_seq_len)
        self.path_weight_net = nn.Sequential(nn.Linear(d_model, 64), nn.ReLU(), nn.Linear(64, 1), nn.Softplus())
        self.message_fn = nn.Sequential(nn.Linear(d_model*2, d_model), nn.LayerNorm(d_model), nn.GELU())
    
    def forward(self, x):
        B, S, D = x.shape
        output = x.clone()
        for pos in range(min(S, 128)):
            structure = self.analyzer._analyze_position(pos)
            if structure['total_ancestors'] > 0:
                weights = self.path_weight_net(x[:, pos])
                output[:, pos] = (x[:, pos] * weights).squeeze(-1)
        return output

class SelfAttentionWithCache(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.d_model = d_model; self.n_heads = n_heads; self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, d_model*3, bias=False); self.out_proj = nn.Linear(d_model, d_model)
    
    def forward(self, x):
        B, S, D = x.shape
        qkv = self.qkv(x).view(B, S, 3, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        scores = (q @ k.transpose(-2, -1)) / (self.head_dim**0.5)
        mask = torch.triu(torch.ones(S, S, device=x.device), diagonal=1).bool()
        scores.masked_fill_(mask, -torch.inf)
        attn = F.softmax(scores, dim=-1) @ v
        return self.out_proj(attn.transpose(1, 2).reshape(B, S, D))

class AdaptiveBlock(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.attn = SelfAttentionWithCache(d_model, n_heads)
        self.ffn = nn.Sequential(nn.Linear(d_model, d_model*4), nn.ReLU(), nn.Linear(d_model*4, d_model))
        self.norm1 = nn.LayerNorm(d_model); self.norm2 = nn.LayerNorm(d_model)
        self.confidence_predictor = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(d_model, 1), nn.Sigmoid())
    
    def forward(self, x):
        x_norm = self.norm1(x)
        attn_out = self.attn(x_norm)
        x = x + attn_out
        x = x + self.ffn(self.norm2(x))
        conf = self.confidence_predictor(x.transpose(1, 2))
        return x, conf

class HSTv3UltraHF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256, num_layers=4):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(2048, d_model)
        self.lattice = PathWeightedLatticeCore(d_model)
        self.blocks = nn.ModuleList([AdaptiveBlock(d_model, 8) for _ in range(num_layers)])
        self.output_proj = nn.Linear(d_model, vocab_size)
    
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        x = self.lattice(x)
        for block in self.blocks:
            x, conf = block(x)
            if conf.mean() > 0.95: break
        return self.output_proj(x)

dataset = load_dataset("wikitext", "wikitext-2-v1", split="train[:10%]")
def tokenize_function(examples):
    return tokenizer(examples["text"], max_length=256, truncation=True, padding='max_length', return_tensors='pt')

tokenized = dataset.map(tokenize_function, batched=True, remove_columns=["text"])
tokenized.set_format('torch', columns=['input_ids', 'attention_mask'])

def create_dataloader(dataset, batch_size=8):
    for i in range(0, len(dataset)-256, batch_size):
        batch = dataset[i:i+batch_size]
        yield batch['input_ids'].to(device), batch['attention_mask'].to(device)

model = HSTv3UltraHF(vocab_size=50257, d_model=256).to(device)
opt = torch.optim.Adam(model.parameters(), 1e-4)
crit = nn.CrossEntropyLoss()
total_steps = 1000
scheduler = get_linear_schedule_with_warmup(opt, num_warmup_steps=100, num_training_steps=total_steps)

for e in range(3):
    for i, (input_ids, attn_mask) in enumerate(create_dataloader(tokenized, 8)):
        if i >= 200: break
        opt.zero_grad()
        logits = model(input_ids)
        loss = crit(logits[:, :-1].reshape(-1, 50257), input_ids[:, 1:].reshape(-1))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        scheduler.step()
        if i % 50 == 0: print(f"Epoch {e+1}, Step {i}: Loss {loss.item():.4f}")

torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v3_hf/hst_v3_hf.pt')
print("✓ HST v3 HF trained and saved")
