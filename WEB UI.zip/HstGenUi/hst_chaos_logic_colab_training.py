# HST Chaos Logic (cl) - Rhythmic Iterative Forward Passes
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn; subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "torch"])
import numpy as np; from sklearn.preprocessing import StandardScaler; from torch.utils.data import DataLoader, TensorDataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/chaos_models', exist_ok=True)
print("HST Chaos Logic - Training")

class ChaoticTimer(nn.Module):
    def __init__(self): super().__init__(); self.rhythm = nn.Parameter(torch.randn(1))
    def forward(self, x): return x * torch.abs(torch.sin(self.rhythm * torch.arange(x.shape[1], device=device).unsqueeze(0)))

class ChaosGenerator(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.forward_pass = nn.Linear(dim, dim)
        self.chaos = ChaoticTimer()
        self.void_state = nn.Parameter(torch.randn(dim))
    
    def forward(self, x, chaos_intensity=0.5):
        base = self.forward_pass(x)
        noise = torch.randn_like(base) * chaos_intensity
        rhythmic = self.chaos(base + noise)
        return rhythmic + self.void_state.view(1, 1, -1)

class HSTChaosLogic(nn.Module):
    def __init__(self, dim=32, layers=4):
        super().__init__()
        self.embed = nn.Linear(1, dim)
        self.chaos_layers = nn.ModuleList([ChaosGenerator(dim) for _ in range(layers)])
        self.head = nn.Linear(dim, 1)
    
    def forward(self, x, chaos_intensity=0.3):
        x = self.embed(x.unsqueeze(-1) if len(x.shape)==2 else x)
        for layer in self.chaos_layers: x = layer(x, chaos_intensity)
        return self.head(x)

data = np.array([np.linspace(0, 5, 100) + 2*np.sin(2*np.pi*np.arange(100)/50) + np.random.normal(0, 0.5, 100) for _ in range(1000)])
scaler = StandardScaler(); data = scaler.fit_transform(data.reshape(-1,1)).reshape(data.shape)
train_loader = DataLoader(TensorDataset(torch.FloatTensor(data[:800]).to(device)), batch_size=32, shuffle=True)
model = HSTChaosLogic().to(device); opt = torch.optim.Adam(model.parameters(), 1e-3); crit = nn.MSELoss()
for e in range(10):
    for X, in train_loader: opt.zero_grad(); loss = crit(model(X, 0.2)[:,:-1], X[:,1:]); loss.backward(); opt.step()
    print(f"Epoch {e+1}: Done")
torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/chaos_models/hst_chaos_trained.pt')
print("✓ HST Chaos Logic saved")
