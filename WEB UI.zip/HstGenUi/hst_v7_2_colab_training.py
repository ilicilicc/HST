# HST v7.2 - Advanced Ultimate
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn, torch.nn.functional as F; subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "torch"])
import numpy as np; from sklearn.preprocessing import StandardScaler; from torch.utils.data import DataLoader, TensorDataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v7_2_models', exist_ok=True)
print("HST v7.2 - Advanced Ultimate")

class AdvancedFlashAttention(nn.Module):
    def __init__(self, d_model, n_heads=8): 
        super().__init__()
        self.d_model = d_model; self.n_heads = n_heads; self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, d_model*3, bias=False); self.out = nn.Linear(d_model, d_model)
    def forward(self, x):
        B, S, D = x.shape
        qkv = self.qkv(x).reshape(B, S, 3, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        if hasattr(F, 'scaled_dot_product_attention'):
            attn = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        else:
            scores = (q @ k.transpose(-2, -1)) / (self.head_dim**0.5)
            mask = torch.triu(torch.ones(S, S, device=x.device), diagonal=1).bool()
            scores.masked_fill_(mask, -torch.inf); attn = F.softmax(scores, dim=-1) @ v
        return self.out(attn.transpose(1, 2).reshape(B, S, D))

class HSTv72(nn.Module):
    def __init__(self, d_model=32, num_layers=4):
        super().__init__()
        self.input = nn.Linear(1, d_model)
        self.attn = nn.ModuleList([AdvancedFlashAttention(d_model) for _ in range(num_layers)])
        self.output = nn.Linear(d_model, 1)
    def forward(self, x):
        x = self.input(x.unsqueeze(-1) if len(x.shape)==2 else x)
        for a in self.attn: x = a(x) + x
        return self.output(x)

data = np.array([np.linspace(0, 5, 100) + 2*np.sin(2*np.pi*np.arange(100)/50) + np.random.normal(0, 0.5, 100) for _ in range(1000)])
scaler = StandardScaler(); data = scaler.fit_transform(data.reshape(-1, 1)).reshape(data.shape)
train_loader = DataLoader(TensorDataset(torch.FloatTensor(data[:800]).to(device)), batch_size=32, shuffle=True)
val_loader = DataLoader(TensorDataset(torch.FloatTensor(data[800:]).to(device)), batch_size=32)
model = HSTv72().to(device); opt = torch.optim.Adam(model.parameters(), 1e-3); crit = nn.MSELoss()
for e in range(10):
    for X, in train_loader: opt.zero_grad(); loss = crit(model(X)[:, :-1], X[:, 1:]); loss.backward(); opt.step()
    print(f"Epoch {e+1}: Done")
torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v7_2_models/hst_v7_2_trained.pt')
print("✓ HST v7.2 saved")
