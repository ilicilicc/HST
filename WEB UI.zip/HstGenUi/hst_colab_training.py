# ============================================================================
# HST Model Training Script for Google Colab
# Purpose: Train HST (Hierarchical Spatial-Temporal) model on GPU
# Instructions: Copy this entire script into a Google Colab cell and run
# ============================================================================

# ============================================================================
# SECTION 1: SETUP & MOUNT GOOGLE DRIVE
# ============================================================================
print("=" * 80)
print("SETTING UP GOOGLE COLAB ENVIRONMENT FOR HST TRAINING")
print("=" * 80)

# Mount Google Drive for data persistence
try:
    from google.colab import drive
    drive.mount('/content/drive')
    print("✓ Google Drive mounted successfully")
    USE_COLAB = True
except:
    print("⚠ Not running in Google Colab, using local storage")
    USE_COLAB = False

import os
import sys

# Create directories for data and models
if USE_COLAB:
    data_dir = '/content/drive/MyDrive/HST_Training/data'
    model_dir = '/content/drive/MyDrive/HST_Training/models'
    checkpoint_dir = '/content/drive/MyDrive/HST_Training/checkpoints'
else:
    data_dir = './HST_data'
    model_dir = './HST_models'
    checkpoint_dir = './HST_checkpoints'

os.makedirs(data_dir, exist_ok=True)
os.makedirs(model_dir, exist_ok=True)
os.makedirs(checkpoint_dir, exist_ok=True)

print(f"✓ Data directory: {data_dir}")
print(f"✓ Model directory: {model_dir}")
print(f"✓ Checkpoint directory: {checkpoint_dir}")

# ============================================================================
# SECTION 2: INSTALL DEPENDENCIES
# ============================================================================
print("\n" + "=" * 80)
print("INSTALLING DEPENDENCIES")
print("=" * 80)

import subprocess

# Core dependencies
packages = [
    "torch",
    "numpy",
    "pandas",
    "matplotlib",
    "tqdm",
    "scikit-learn"
]

for package in packages:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", package])
    print(f"✓ Installed {package}")

print("✓ All dependencies installed")

# ============================================================================
# SECTION 3: VERIFY GPU AVAILABILITY
# ============================================================================
print("\n" + "=" * 80)
print("GPU AVAILABILITY CHECK")
print("=" * 80)

import torch

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

if torch.cuda.is_available():
    print(f"GPU Name: {torch.cuda.get_device_name(0)}")
    print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
    print(f"CUDA Version: {torch.version.cuda}")
else:
    print("⚠ WARNING: GPU not available, training will be slow!")

# ============================================================================
# SECTION 4: DEFINE HST MODEL CLASS
# ============================================================================
print("\n" + "=" * 80)
print("DEFINING HST MODEL ARCHITECTURE")
print("=" * 80)

import torch.nn as nn
import torch.nn.functional as F
from torch.nn import TransformerEncoderLayer, TransformerEncoder

class CompleteLatticeCore(nn.Module):
    """Complete Lattice Core - Graph Neural Network based memory"""
    def __init__(self, feature_dim, lattice_levels=4):
        super(CompleteLatticeCore, self).__init__()
        self.feature_dim = feature_dim
        self.lattice_levels = lattice_levels
        
        # Create lattice projections for each level
        self.level_projections = nn.ModuleList([
            nn.Linear(feature_dim, feature_dim) 
            for _ in range(lattice_levels)
        ])
        
        # Path aggregation
        self.path_weights = nn.ModuleList([
            nn.Linear(feature_dim, 1) 
            for _ in range(lattice_levels)
        ])
    
    def forward(self, x):
        # x shape: (batch, seq_len, feature_dim)
        batch_size, seq_len, _ = x.shape
        
        # Process through lattice levels
        lattice_outputs = []
        for level, (proj, weights) in enumerate(zip(self.level_projections, self.path_weights)):
            level_output = proj(x)
            level_weights = F.softmax(weights(level_output), dim=1)
            weighted_output = level_output * level_weights
            lattice_outputs.append(weighted_output)
        
        # Aggregate lattice outputs
        aggregated = torch.stack(lattice_outputs, dim=0).mean(dim=0)
        return aggregated


class HarmonicHorizonPredictor(nn.Module):
    """Harmonic Horizon Predictor - Frequency-based prediction"""
    def __init__(self, feature_dim, harmonic_components=8):
        super(HarmonicHorizonPredictor, self).__init__()
        self.feature_dim = feature_dim
        self.harmonic_components = harmonic_components
        
        # Fourier components
        self.harmonic_layers = nn.ModuleList([
            nn.Linear(feature_dim, feature_dim) 
            for _ in range(harmonic_components)
        ])
        
        self.combination = nn.Linear(feature_dim * harmonic_components, feature_dim)
    
    def forward(self, x):
        # x shape: (batch, seq_len, feature_dim)
        harmonic_outputs = []
        for layer in self.harmonic_layers:
            harmonic_outputs.append(layer(x))
        
        # Concatenate and combine
        combined = torch.cat(harmonic_outputs, dim=-1)
        output = self.combination(combined)
        return output


class DiamondMixer(nn.Module):
    """Diamond Mixer - Lossless non-linear transformation"""
    def __init__(self, feature_dim):
        super(DiamondMixer, self).__init__()
        self.feature_dim = feature_dim
        
        # Synthesis and analysis paths
        self.synthesis = nn.Sequential(
            nn.Linear(feature_dim, feature_dim * 2),
            nn.ReLU(),
            nn.Linear(feature_dim * 2, feature_dim)
        )
        
        self.analysis = nn.Sequential(
            nn.Linear(feature_dim, feature_dim * 2),
            nn.ReLU(),
            nn.Linear(feature_dim * 2, feature_dim)
        )
    
    def forward(self, u):
        # x = u (synthesis), y = analysis
        x = self.synthesis(u)
        y = self.analysis(u)
        
        # Diamond mixing: synthesis + analysis
        Z = (x + y) / 2  # Synthesis
        W = (y - x) / 2  # Analysis
        
        # Recombine
        output = Z + W
        return output


class HSTLayer(nn.Module):
    """Complete HST Layer combining all components"""
    def __init__(self, feature_dim, lattice_levels=4, harmonic_components=8):
        super(HSTLayer, self).__init__()
        self.lattice = CompleteLatticeCore(feature_dim, lattice_levels)
        self.horizon = HarmonicHorizonPredictor(feature_dim, harmonic_components)
        self.mixer = DiamondMixer(feature_dim)
        
        # Normalization
        self.norm1 = nn.LayerNorm(feature_dim)
        self.norm2 = nn.LayerNorm(feature_dim)
        self.norm3 = nn.LayerNorm(feature_dim)
    
    def forward(self, x):
        # Lattice processing
        lattice_out = self.lattice(x)
        x = self.norm1(x + lattice_out)
        
        # Horizon prediction
        horizon_out = self.horizon(x)
        x = self.norm2(x + horizon_out)
        
        # Diamond mixing
        mixer_out = self.mixer(x)
        x = self.norm3(x + mixer_out)
        
        return x


class HST(nn.Module):
    """Complete HST Model"""
    def __init__(
        self,
        feature_dim=32,
        num_layers=4,
        lattice_levels=4,
        harmonic_components=8,
        sequence_length=100,
        output_dim=None
    ):
        super(HST, self).__init__()
        self.feature_dim = feature_dim
        self.sequence_length = sequence_length
        self.output_dim = output_dim or feature_dim
        
        # Input projection
        self.input_proj = nn.Linear(1, feature_dim)
        
        # HST layers
        self.hst_layers = nn.ModuleList([
            HSTLayer(feature_dim, lattice_levels, harmonic_components)
            for _ in range(num_layers)
        ])
        
        # Output projection
        self.output_proj = nn.Linear(feature_dim, self.output_dim)
    
    def forward(self, x):
        # x shape: (batch, seq_len) or (batch, seq_len, 1)
        if len(x.shape) == 2:
            x = x.unsqueeze(-1)
        
        # Project input
        x = self.input_proj(x)
        
        # Process through HST layers
        for layer in self.hst_layers:
            x = layer(x)
        
        # Project output
        output = self.output_proj(x)
        
        return output

print("✓ HST Model architecture defined")

# ============================================================================
# SECTION 5: CREATE SYNTHETIC TRAINING DATA
# ============================================================================
print("\n" + "=" * 80)
print("GENERATING SYNTHETIC TRAINING DATA")
print("=" * 80)

import numpy as np
from sklearn.preprocessing import StandardScaler

def create_synthetic_data(n_samples=1000, sequence_length=100, n_features=1):
    """Create synthetic time series data"""
    data = []
    
    for i in range(n_samples):
        # Random walk with drift
        t = np.arange(sequence_length)
        trend = np.linspace(0, 5, sequence_length)
        noise = np.random.normal(0, 0.5, sequence_length)
        signal = trend + 2 * np.sin(2 * np.pi * t / 50) + noise
        data.append(signal)
    
    data = np.array(data)
    
    # Normalize
    scaler = StandardScaler()
    data = scaler.fit_transform(data.reshape(-1, 1)).reshape(data.shape)
    
    return data, scaler

# Generate data
print("Generating 1000 synthetic sequences...")
train_data, scaler = create_synthetic_data(n_samples=1000, sequence_length=100)
print(f"✓ Generated training data shape: {train_data.shape}")

# Create train/validation split
train_size = int(0.8 * len(train_data))
train_data_final = train_data[:train_size]
val_data = train_data[train_size:]

print(f"✓ Train set size: {len(train_data_final)}")
print(f"✓ Validation set size: {len(val_data)}")

# ============================================================================
# SECTION 6: TRAINING LOOP
# ============================================================================
print("\n" + "=" * 80)
print("TRAINING HST MODEL ON GPU")
print("=" * 80)

from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

# Convert to tensors
train_tensor = torch.FloatTensor(train_data_final).to(device)
val_tensor = torch.FloatTensor(val_data).to(device)

# Create datasets
train_dataset = TensorDataset(train_tensor)
val_dataset = TensorDataset(val_tensor)

# Create dataloaders
batch_size = 32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

print(f"✓ Batch size: {batch_size}")
print(f"✓ Train batches: {len(train_loader)}")
print(f"✓ Validation batches: {len(val_loader)}")

# Initialize model
model = HST(
    feature_dim=32,
    num_layers=4,
    lattice_levels=4,
    harmonic_components=8,
    sequence_length=100,
    output_dim=1
).to(device)

print(f"\n✓ Model initialized and moved to {device}")
print(f"✓ Total parameters: {sum(p.numel() for p in model.parameters()):,}")

# Loss and optimizer
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, mode='min', factor=0.5, patience=3, verbose=True
)

# Training configuration
num_epochs = 10
best_val_loss = float('inf')

print("\n" + "=" * 80)
print("STARTING TRAINING")
print("=" * 80 + "\n")

# Training loop
for epoch in range(num_epochs):
    # Training phase
    model.train()
    train_loss = 0.0
    train_bar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{num_epochs} [Train]')
    
    for batch in train_bar:
        X = batch[0].to(device)
        
        # Forward pass
        output = model(X)
        
        # Create target (next token prediction)
        target = X[:, 1:, :].to(device)
        output = output[:, :-1, :]
        
        loss = criterion(output, target)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        train_loss += loss.item()
        train_bar.set_postfix({'loss': loss.item():.6f})
    
    avg_train_loss = train_loss / len(train_loader)
    
    # Validation phase
    model.eval()
    val_loss = 0.0
    val_bar = tqdm(val_loader, desc=f'Epoch {epoch+1}/{num_epochs} [Val]')
    
    with torch.no_grad():
        for batch in val_bar:
            X = batch[0].to(device)
            
            output = model(X)
            target = X[:, 1:, :].to(device)
            output = output[:, :-1, :]
            
            loss = criterion(output, target)
            val_loss += loss.item()
            val_bar.set_postfix({'loss': loss.item():.6f})
    
    avg_val_loss = val_loss / len(val_loader)
    
    # Print epoch summary
    print(f"\nEpoch {epoch+1}/{num_epochs}")
    print(f"  Train Loss: {avg_train_loss:.6f}")
    print(f"  Val Loss:   {avg_val_loss:.6f}")
    
    # Save best model
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        best_epoch = epoch + 1
        checkpoint_path = os.path.join(checkpoint_dir, f'hst_best_epoch_{best_epoch}.pt')
        torch.save({
            'epoch': epoch + 1,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'val_loss': avg_val_loss,
            'scaler': scaler,
        }, checkpoint_path)
        print(f"  ✓ Saved best model at epoch {best_epoch}")
    
    # Learning rate scheduling
    scheduler.step(avg_val_loss)

print("\n" + "=" * 80)
print("TRAINING COMPLETED")
print("=" * 80)
print(f"Best validation loss: {best_val_loss:.6f} (Epoch {best_epoch})")
print(f"Saved checkpoint: {checkpoint_path}")

# ============================================================================
# SECTION 7: SAVE MODEL
# ============================================================================
print("\n" + "=" * 80)
print("SAVING TRAINED MODEL")
print("=" * 80)

# Save final model
final_model_path = os.path.join(model_dir, 'aethyr_hst_v1.pt')
torch.save({
    'epoch': num_epochs,
    'model_state_dict': model.state_dict(),
    'optimizer_state_dict': optimizer.state_dict(),
    'scaler': scaler,
}, final_model_path)

print(f"✓ Model saved to: {final_model_path}")
print(f"✓ Model size: {os.path.getsize(final_model_path) / 1e6:.2f} MB")

# ============================================================================
# SECTION 8: INFERENCE EXAMPLE
# ============================================================================
print("\n" + "=" * 80)
print("INFERENCE EXAMPLE")
print("=" * 80)

model.eval()
with torch.no_grad():
    # Use first validation sample
    sample = val_data[0:1]
    sample_tensor = torch.FloatTensor(sample).to(device)
    
    prediction = model(sample_tensor)
    prediction_np = prediction.cpu().numpy()
    
    print(f"Input shape: {sample.shape}")
    print(f"Output shape: {prediction_np.shape}")
    print(f"First 5 predictions: {prediction_np[0, :5, 0]}")
    print(f"Last 5 actual values: {sample[0, -5:]}")

print("\n" + "=" * 80)
print("✓ HST TRAINING PIPELINE COMPLETE!")
print("=" * 80)
print(f"\nYour trained model is saved at: {final_model_path}")
print(f"Checkpoint saved at: {checkpoint_path}")
print("\nNext steps:")
print("1. Download the model from Google Drive")
print("2. Integrate into your AethyrHST chat application")
print("3. Use Gradio to wrap the model for deployment")
