# HST v8 - Test Generation from Trained Model
from google.colab import drive; drive.mount('/content/drive')
import torch, torch.nn as nn, torch.nn.functional as F
from transformers import AutoTokenizer

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class HSTv8(nn.Module):
    def __init__(self, vocab_size=50257, hidden_dim=768, num_layers=8, num_heads=12, max_seq_len=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, hidden_dim)
        self.pos_embedding = nn.Embedding(max_seq_len, hidden_dim)
        self.layers = nn.ModuleList([HSTv8Block(hidden_dim, num_heads) for _ in range(num_layers)])
        self.output_proj = nn.Linear(hidden_dim, vocab_size)
        
    def forward(self, input_ids):
        seq_len = input_ids.shape[1]
        pos_ids = torch.arange(seq_len, device=input_ids.device).unsqueeze(0)
        x = self.embedding(input_ids) + self.pos_embedding(pos_ids)
        for layer in self.layers:
            x = layer(x)
        return self.output_proj(x)

class HSTv8Block(nn.Module):
    def __init__(self, hidden_dim, num_heads):
        super().__init__()
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads, batch_first=True)
        self.ffn = nn.Sequential(nn.Linear(hidden_dim, 3072), nn.ReLU(), nn.Linear(3072, hidden_dim))
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(hidden_dim)
    
    def forward(self, x):
        x = x + self.attention(self.norm1(x), self.norm1(x), self.norm1(x))[0]
        x = x + self.ffn(self.norm2(x))
        return x

tokenizer = AutoTokenizer.from_pretrained("gpt2")
model = HSTv8(vocab_size=len(tokenizer), hidden_dim=768, num_layers=8, num_heads=12)
model.to(device)
model.load_state_dict(torch.load("/content/drive/MyDrive/HST_Training/v8_hf/hst_v8_trained.pt", map_location=device))
model.eval()

def generate_text(prompt, max_tokens=100, temperature=0.7, top_k=50):
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        for _ in range(max_tokens):
            outputs = model(input_ids)
            logits = outputs[:, -1, :] / temperature
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            if next_token.item() == tokenizer.eos_token_id:
                break
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

print("\n" + "="*60)
print("TESTING TEXT GENERATION - HST v8")
print("="*60 + "\n")
for prompt in ["The future of AI", "Machine learning enables", "Innovation starts with"]:
    print(f"Prompt: \"{prompt}\"")
    print(f"Generated:\n{generate_text(prompt, max_tokens=80)}\n")
