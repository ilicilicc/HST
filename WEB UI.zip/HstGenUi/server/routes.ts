import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatSchema, insertMessageSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Create a new chat
  app.post("/api/chats", async (req, res) => {
    try {
      const { title } = req.body;
      const chat = await storage.createChat({ title });
      res.json(chat);
    } catch (error) {
      res.status(400).json({ error: "Failed to create chat" });
    }
  });

  // Get a specific chat
  app.get("/api/chats/:id", async (req, res) => {
    try {
      const chat = await storage.getChat(req.params.id);
      if (!chat) {
        return res.status(404).json({ error: "Chat not found" });
      }
      res.json(chat);
    } catch (error) {
      res.status(400).json({ error: "Failed to get chat" });
    }
  });

  // Get all messages for a chat
  app.get("/api/chats/:chatId/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(req.params.chatId);
      res.json(messages);
    } catch (error) {
      res.status(400).json({ error: "Failed to get messages" });
    }
  });

  // Add a message to a chat
  app.post("/api/chats/:chatId/messages", async (req, res) => {
    try {
      const { chatId } = req.params;
      const { role, content } = req.body;

      // Validate input
      if (!role || !content) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Add user message
      const userMessage = await storage.addMessage({
        chatId,
        role: "user",
        content,
      });

      res.json(userMessage);

      // Mock AI response - simulate async processing
      setTimeout(async () => {
        const aiResponses: Record<string, string> = {
          default:
            "Based on your request, here's a generated response. Real AI integration coming soon.",
          architecture:
            "For architectural concepts, I can help generate structural designs using the Aethyr design principles with golden ratio proportions and premium materials.",
          design:
            "Design generation is an advanced capability. I can create technical specifications, material palettes, and visual concepts.",
        };

        const keyword = content.toLowerCase();
        let response = aiResponses.default;
        if (keyword.includes("architecture"))
          response = aiResponses.architecture;
        if (keyword.includes("design")) response = aiResponses.design;

        await storage.addMessage({
          chatId,
          role: "assistant",
          content: response,
        });
      }, 1500);
    } catch (error) {
      res.status(400).json({ error: "Failed to add message" });
    }
  });

  return httpServer;
}
