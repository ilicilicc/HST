# HST v3 Ultra - Test Generation from Trained Model
from google.colab import drive; drive.mount('/content/drive')
import torch, torch.nn as nn, torch.nn.functional as F
from transformers import AutoTokenizer

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Device: {device}")

# ==================== HST v3 Ultra Architecture ====================
class FullLatticeFieldAnalyzer(nn.Module):
    def __init__(self, max_seq_len=512):
        super().__init__()
        spine = [0, 2, 4]
        while spine[-1] < max_seq_len:
            spine.append(2*spine[-1] + spine[-2] if len(spine)>1 else 0)
        self.register_buffer('spine', torch.tensor(spine[:min(len(spine), 10)], dtype=torch.long))
    
    def _analyze_position(self, pos):
        levels = {0: [pos]}
        visited = {pos}
        current_level = [pos]
        level = 0
        while current_level and level < 10:
            next_level = set()
            for node in current_level:
                for s in self.spine:
                    if s < node and s not in visited: 
                        visited.add(s); next_level.add(s)
            current_level = list(next_level)
            level += 1
            if current_level: levels[level] = current_level.copy()
        return {'levels': levels, 'total_ancestors': len(visited)-1, 'max_depth': max(levels.keys()) if levels else 0}

class PathWeightedLatticeCore(nn.Module):
    def __init__(self, d_model, max_seq_len=512):
        super().__init__()
        self.analyzer = FullLatticeFieldAnalyzer(max_seq_len)
        self.path_weight_net = nn.Sequential(nn.Linear(d_model, 64), nn.ReLU(), nn.Linear(64, 1), nn.Softplus())
        self.message_fn = nn.Sequential(nn.Linear(d_model*2, d_model), nn.LayerNorm(d_model), nn.GELU())
    
    def forward(self, x):
        B, S, D = x.shape
        output = x.clone()
        for pos in range(min(S, 128)):
            structure = self.analyzer._analyze_position(pos)
            if structure['total_ancestors'] > 0:
                weights = self.path_weight_net(x[:, pos])
                output[:, pos] = (x[:, pos] * weights).squeeze(-1)
        return output

class SelfAttentionWithCache(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.d_model = d_model; self.n_heads = n_heads; self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, d_model*3, bias=False); self.out_proj = nn.Linear(d_model, d_model)
    
    def forward(self, x):
        B, S, D = x.shape
        qkv = self.qkv(x).view(B, S, 3, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        scores = (q @ k.transpose(-2, -1)) / (self.head_dim**0.5)
        mask = torch.triu(torch.ones(S, S, device=x.device), diagonal=1).bool()
        scores.masked_fill_(mask, -torch.inf)
        attn = F.softmax(scores, dim=-1) @ v
        return self.out_proj(attn.transpose(1, 2).reshape(B, S, D))

class AdaptiveBlock(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.attn = SelfAttentionWithCache(d_model, n_heads)
        self.ffn = nn.Sequential(nn.Linear(d_model, d_model*4), nn.ReLU(), nn.Linear(d_model*4, d_model))
        self.norm1 = nn.LayerNorm(d_model); self.norm2 = nn.LayerNorm(d_model)
        self.confidence_predictor = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(d_model, 1), nn.Sigmoid())
    
    def forward(self, x):
        x_norm = self.norm1(x)
        attn_out = self.attn(x_norm)
        x = x + attn_out
        x = x + self.ffn(self.norm2(x))
        conf = self.confidence_predictor(x.transpose(1, 2))
        return x, conf

class HSTv3UltraHF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256, num_layers=4):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(2048, d_model)
        self.lattice = PathWeightedLatticeCore(d_model)
        self.blocks = nn.ModuleList([AdaptiveBlock(d_model, 8) for _ in range(num_layers)])
        self.output_proj = nn.Linear(d_model, vocab_size)
    
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        x = self.lattice(x)
        for block in self.blocks:
            x, conf = block(x)
            if conf.mean() > 0.95: break
        return self.output_proj(x)

# ==================== Load Model & Tokenizer ====================
tokenizer = AutoTokenizer.from_pretrained("gpt2")
model = HSTv3UltraHF(vocab_size=len(tokenizer), d_model=256, num_layers=4)
model.to(device)

model_path = "/content/drive/MyDrive/HST_Training/v3_hf/hst_v3_hf.pt"
try:
    model.load_state_dict(torch.load(model_path, map_location=device))
    print(f"✓ Loaded model from {model_path}")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    exit(1)

model.eval()

# ==================== Text Generation ====================
def generate_text(prompt, max_tokens=100, temperature=0.7, top_k=50):
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        for _ in range(max_tokens):
            outputs = model(input_ids)
            logits = outputs[:, -1, :] / temperature
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            if next_token.item() == tokenizer.eos_token_id:
                break
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

# ==================== Test Generation ====================
print("\n" + "="*60)
print("TESTING TEXT GENERATION - HST v3 Ultra")
print("="*60 + "\n")

test_prompts = [
    "The future of artificial intelligence",
    "In the beginning, there was",
    "Machine learning is a powerful tool for",
    "The most important discovery in science",
]

for i, prompt in enumerate(test_prompts, 1):
    print(f"Prompt {i}: \"{prompt}\"")
    print("-" * 60)
    generated = generate_text(prompt, max_tokens=80, temperature=0.8)
    print(f"Generated:\n{generated}\n")

print("="*60)
print("✓ Generation test complete!")
print("="*60)
