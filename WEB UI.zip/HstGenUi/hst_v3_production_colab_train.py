#!/usr/bin/env python3
"""
HST v3 Ultra - Production-Grade Training Script
Larger Model: 1024-dim, 24-layer (~2.7B params, 11GB final)
Fixed: In-place operations, shape mismatches, loss computation
GPU Limit: 80% of 16GB = 12.8GB max
"""
import os
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True,max_split_size_mb:512'

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.amp import autocast, GradScaler
from transformers import AutoTokenizer, DataCollatorForLanguageModeling, get_linear_schedule_with_warmup
from datasets import load_dataset
import gc
import psutil

try:
    from google.colab import drive
    drive.mount('/content/drive')
    save_dir = '/content/drive/MyDrive/HST_Training/v3_ultra'
except:
    save_dir = './HST_Training/v3_ultra'

os.makedirs(save_dir, exist_ok=True)
device = torch.device('cuda')
torch.cuda.empty_cache()

print("=" * 80)
print("HST v3 Ultra - COLAB OPTIMIZED (1024-dim, 24-layer, ~2.7B params)")
print("=" * 80)

def print_memory():
    torch.cuda.synchronize()
    torch.cuda.empty_cache()
    gpu_mem = torch.cuda.memory_allocated() / 1e9
    gpu_max = torch.cuda.get_device_properties(device).total_memory / 1e9
    gpu_pct = (gpu_mem / gpu_max) * 100
    ram = psutil.virtual_memory()
    ram_pct = ram.percent
    print(f"GPU: {gpu_mem:.2f}GB / {gpu_max:.2f}GB ({gpu_pct:.1f}%) | RAM: {ram.used/1e9:.1f}GB / {ram.total/1e9:.1f}GB ({ram_pct:.1f}%)")

# ==================== LATTICE CORE (FIXED: No in-place ops) ====================
class FullLatticeFieldAnalyzer(nn.Module):
    def __init__(self, max_seq_len=512):
        super().__init__()
        spine = [0, 2, 4]
        while True:
            next_val = 2*spine[-1] + 2*spine[-2] + 2*spine[-3]
            if next_val >= max_seq_len:
                break
            spine.append(next_val)
        
        self.register_buffer('spine', torch.tensor(spine, dtype=torch.long))
        self.lattice_structure = {}
        for pos in spine:
            if pos < max_seq_len:
                self.lattice_structure[pos] = self._analyze_position(pos)
    
    def _analyze_position(self, pos):
        levels = {0: [pos]}
        visited = {pos}
        current = [pos]
        level = 0
        
        while current and level < 6:
            next_level = set()
            for node in current:
                ancestors = self._get_ancestors(node)
                for anc in ancestors:
                    if anc not in visited and anc >= 0:
                        visited.add(anc)
                        next_level.add(anc)
            current = list(next_level)
            level += 1
            if current:
                levels[level] = current.copy()
        
        max_depth = max(levels.keys()) if levels else 0
        path_counts = self._compute_paths(pos, levels, max_depth)
        return {'levels': levels, 'path_counts': path_counts, 'total_ancestors': len(visited) - 1, 'max_depth': max_depth}
    
    def _get_ancestors(self, pos):
        try:
            idx = (self.spine == pos).nonzero(as_tuple=True)[0].item()
            if idx >= 3:
                return [self.spine[idx-1].item(), self.spine[idx-2].item(), self.spine[idx-3].item()]
        except:
            pass
        return []
    
    def _compute_paths(self, pos, levels, max_depth):
        path_counts = {pos: 1}
        for level in sorted(levels.keys(), reverse=True):
            for node in levels[level]:
                if node == pos: continue
                if level == max_depth:
                    path_counts[node] = 1
                    continue
                count = sum(path_counts.get(child, 0) for child in levels.get(level + 1, []) if node in self._get_ancestors(child))
                if level != 0:
                    path_counts[node] = count
        path_counts.pop(pos, None)
        return path_counts
    
    def get_structure(self, pos: int):
        return self.lattice_structure.get(pos)

class PathWeightedLatticeCore(nn.Module):
    def __init__(self, d_model, max_seq_len=512):
        super().__init__()
        self.analyzer = FullLatticeFieldAnalyzer(max_seq_len)
        self.path_weight_net = nn.Sequential(
            nn.Linear(1, 32), nn.ReLU(), nn.Linear(32, 1), nn.Softplus()
        )
        self.message_fn = nn.Sequential(
            nn.Linear(d_model * 2, d_model), nn.GELU()
        )
        self.aggregate_gru = nn.GRU(d_model, d_model, batch_first=True)
        self.gate = nn.Sequential(nn.Linear(d_model * 2, d_model), nn.Sigmoid())
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, S, D = x.shape
        h_out = x.clone()
        updates = {}
        
        for spine_pos in self.analyzer.spine[self.analyzer.spine < S]:
            pos = spine_pos.item()
            if pos < 3: continue
            
            struct = self.analyzer.get_structure(pos)
            if not struct or struct['total_ancestors'] == 0: continue
            
            ancestors = []
            weights = []
            for level in struct['levels']:
                if level > 0:
                    for anc in struct['levels'][level]:
                        if anc < S:
                            ancestors.append(anc)
                            weights.append(struct['path_counts'].get(anc, 1))
            
            if not ancestors: continue
            ancestors, weights = ancestors[:16], weights[:16]
            
            w_tensor = torch.tensor(weights, device=x.device, dtype=torch.float32).view(-1, 1)
            w_scaled = self.path_weight_net(w_tensor).squeeze()
            
            h_current = updates.get(pos, x[:, pos, :])
            msgs = [self.message_fn(torch.cat([x[:, a, :], h_current], dim=-1)) for a in ancestors]
            msg_stack = torch.stack(msgs, dim=1)
            w_expand = w_scaled.view(1, -1, 1).expand(B, -1, D)
            
            agg, _ = self.aggregate_gru(msg_stack * w_expand)
            agg = agg[:, -1, :]
            
            g = self.gate(torch.cat([agg, h_current], dim=-1))
            updates[pos] = g * agg + (1 - g) * h_current
        
        if updates:
            for pos, new_val in updates.items():
                h_out[:, pos, :] = new_val
        
        torch.cuda.empty_cache()
        return h_out

class CompleteLatticeCore(nn.Module):
    def __init__(self, d_model, max_seq_len=512):
        super().__init__()
        self.lattice = PathWeightedLatticeCore(d_model, max_seq_len)
    
    def forward(self, x):
        return self.lattice(x)

# ==================== TRANSFORMER BLOCKS ====================
class LightweightAttention(nn.Module):
    def __init__(self, d_model, n_heads=8):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        
        self.q = nn.Linear(d_model, d_model, bias=False)
        self.k = nn.Linear(d_model, d_model, bias=False)
        self.v = nn.Linear(d_model, d_model, bias=False)
        self.out = nn.Linear(d_model, d_model, bias=False)
    
    def forward(self, x):
        B, S, D = x.shape
        q = self.q(x).view(B, S, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k(x).view(B, S, self.n_heads, self.head_dim).transpose(1, 2)
        v = self.v(x).view(B, S, self.n_heads, self.head_dim).transpose(1, 2)
        
        scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)
        mask = torch.triu(torch.ones(S, S, dtype=torch.bool, device=x.device), diagonal=1)
        scores.masked_fill_(mask[None, None, :, :], torch.finfo(scores.dtype).min)
        
        attn = F.softmax(scores, dim=-1)
        out = torch.matmul(attn, v).transpose(1, 2).contiguous().view(B, S, D)
        return self.out(out)

class AdaptiveBlock(nn.Module):
    def __init__(self, d_model, n_heads=8):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attn = LightweightAttention(d_model, n_heads)
        self.norm2 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.GELU(),
            nn.Linear(d_model * 2, d_model)
        )
        self.conf_pred = nn.Linear(d_model, 1)
    
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        conf = torch.sigmoid(self.conf_pred(x)).mean()
        return x, conf

class HarmonicHorizonPredictor(nn.Module):
    def __init__(self, d_model, vocab_size, horizon=8):
        super().__init__()
        self.heads = nn.ModuleList([nn.Linear(d_model, vocab_size) for _ in range(horizon)])
    
    def forward(self, x):
        return torch.stack([h(x) for h in self.heads], dim=2)

# ==================== MODEL ====================
class HSTv3Ultra(nn.Module):
    def __init__(self, vocab_size=50257, d_model=1024, n_heads=8, n_layers=24, max_seq_len=512, horizon=8):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(max_seq_len, d_model)
        self.lattice = CompleteLatticeCore(d_model, max_seq_len)
        
        self.n_bottom = n_layers // 2
        self.bottom = nn.ModuleList([AdaptiveBlock(d_model, n_heads) for _ in range(self.n_bottom)])
        self.top = nn.ModuleList([AdaptiveBlock(d_model, n_heads) for _ in range(n_layers - self.n_bottom)])
        
        self.horizon = HarmonicHorizonPredictor(d_model, vocab_size, horizon)
        self.norm = nn.LayerNorm(d_model)
        self.out_proj = nn.Linear(d_model, vocab_size, bias=False)
        self.out_proj.weight = self.embed.weight
    
    def forward(self, input_ids):
        x = self.embed(input_ids) + self.pos_embed(torch.arange(input_ids.size(1), device=device))
        x = self.lattice(x)
        
        confs = []
        depth = self.n_bottom
        for i, block in enumerate(self.bottom):
            x, conf = block(x)
            confs.append(conf)
            if i >= 1 and conf.item() > 0.92:
                depth = i + 1
                break
        
        for block in self.top:
            x, _ = block(x)
        
        x = self.norm(x)
        return {
            'logits': self.out_proj(x),
            'horizon_logits': self.horizon(x),
            'bottom_depth': torch.tensor(depth, device=device),
            'confidence': torch.stack(confs).mean() if confs else torch.tensor(0.5, device=device)
        }

# ==================== LOSS (BULLETPROOF) ====================
def compute_loss(output, targets, horizon=8, gamma=0.95, pad_id=50256):
    """
    FIXED: Handles all shape mismatches from variable-length batches
    """
    logits = output['logits']                  # (B, S, V)
    horizon_logits = output['horizon_logits']  # (B, S, H, V)
    
    B, S = targets.shape
    V = logits.size(-1)
    
    # CRITICAL: Ensure logits and targets have same length
    logits = logits[:, :S]
    horizon_logits = horizon_logits[:, :S]
    
    # Main loss: t -> t+1 prediction
    pred_logits = logits[:, :-1].reshape(-1, V)      # (B*(S-1), V)
    pred_targets = targets[:, 1:].reshape(-1)        # (B*(S-1),)
    loss = F.cross_entropy(pred_logits, pred_targets, ignore_index=pad_id)
    
    # Horizon losses: t -> t+k prediction
    for k in range(1, min(horizon + 1, S)):
        # Slice both to same length for step k
        h_logits_k = horizon_logits[:, :S-k, k-1]   # (B, S-k, V)
        h_targets_k = targets[:, k:]                 # (B, S-k)
        
        # Safety check
        if h_logits_k.shape[1] == 0 or h_targets_k.shape[1] == 0:
            continue
        
        # Ensure exact match
        min_len = min(h_logits_k.shape[1], h_targets_k.shape[1])
        h_logits_k = h_logits_k[:, :min_len].reshape(-1, V)
        h_targets_k = h_targets_k[:, :min_len].reshape(-1)
        
        loss += (gamma ** k) * F.cross_entropy(h_logits_k, h_targets_k, ignore_index=pad_id)
    
    # Early-exit consistency
    depth = output['bottom_depth'].float()
    conf = output['confidence']
    loss += 0.05 * F.mse_loss(conf, depth / 4.0)
    
    return loss

# ==================== INITIALIZE ====================
print("\n[1/5] Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

print("[2/5] Building COLAB-OPTIMIZED model (1024-dim, 24-layer, 8-head)...")
model = HSTv3Ultra(
    d_model=1024,
    n_heads=8,
    n_layers=24,
    max_seq_len=512,
    horizon=8
).to(device)

total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"Model: {total_params/1e9:.2f}B params ({total_params/1e6:.0f}M)")
print(f"Trainable: {trainable_params/1e9:.2f}B params")
print(f"Final size (FP32): {(total_params * 4) / 1e9:.1f}GB")
print(f"Training uses FP16 autocast for memory efficiency")
print_memory()

print("\n[3/5] Setting up 8-bit optimizer + gradient checkpointing...")
try:
    import bitsandbytes as bnb
    optimizer = bnb.optim.Adam8bit(model.parameters(), lr=3e-4, betas=(0.9, 0.999), weight_decay=0.01)
    print("✓ Using 8-bit AdamW (massive memory savings)")
except ImportError:
    print("⚠ bitsandbytes not available, using standard AdamW")
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=0.01)

scaler = GradScaler()
scheduler = get_linear_schedule_with_warmup(optimizer, 3000, 100000)

print("[4/5] Loading dataset...")
dataset = load_dataset("HuggingFaceFW/fineweb-edu", "sample-10BT", split="train", streaming=True)

def tokenize(ex):
    t = tokenizer(ex["text"], truncation=True, max_length=512)["input_ids"]
    return {"input_ids": t}

stream = dataset.map(tokenize, batched=True, batch_size=500, remove_columns=dataset.column_names)
collator = DataCollatorForLanguageModeling(tokenizer, mlm=False)
loader = DataLoader(stream, batch_size=1, collate_fn=collator)

print("[5/5] Starting training loop...\n")

# ==================== TRAINING ====================
model.train()
step = 0

for batch in loader:
    if step >= 100000: break
    
    ids = batch["input_ids"].to(device)
    
    optimizer.zero_grad()
    with autocast(device_type='cuda', dtype=torch.float16):
        out = model(ids)
        loss = compute_loss(out, ids)
    
    scaler.scale(loss).backward()
    scaler.unscale_(optimizer)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(optimizer)
    scaler.update()
    scheduler.step()
    
    if step % 100 == 0:
        print(f"Step {step:6d} | Loss {loss.item():.4f} | Depth {out['bottom_depth'].item():.0f} | Conf {out['confidence'].item():.3f} | ", end="")
        print_memory()
    
    if step % 5000 == 0 and step > 0:
        torch.save(model.state_dict(), f"{save_dir}/ckpt_step_{step}.pt")
        print(f"  ✓ Checkpoint saved at step {step}")
    
    if step % 50 == 0:
        torch.cuda.empty_cache()
        gc.collect()
    
    step += 1

torch.save(model.state_dict(), f'{save_dir}/hst_v3_ultra_final.pt')
print("\n✅ TRAINING COMPLETE - Model saved!")
print_memory()
