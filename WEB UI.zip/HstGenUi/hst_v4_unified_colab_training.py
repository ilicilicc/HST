# HST v4 Unified - Token & Chunk Processing Modes with ChunkEncoder/Decoder
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn; subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "torch"])
import numpy as np; from sklearn.preprocessing import StandardScaler; from torch.utils.data import DataLoader, TensorDataset; from tqdm import tqdm
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v4_unified_models', exist_ok=True)
print("HST v4 Unified - Token & Chunk Modes")

class ChunkEncoder(nn.Module):
    def __init__(self, d_model, chunk_size=16):
        super().__init__()
        self.chunk_size = chunk_size
        self.local_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model, 4, d_model*4, batch_first=True),
            num_layers=2
        )
        self.pooling = nn.Sequential(nn.Linear(d_model, d_model), nn.LayerNorm(d_model))
    
    def forward(self, tokens):
        B, S, D = tokens.shape
        num_chunks = S // self.chunk_size
        chunks = tokens[:, :num_chunks*self.chunk_size].view(B*num_chunks, self.chunk_size, D)
        encoded = self.local_encoder(chunks)
        pooled = encoded.mean(dim=1)
        return self.pooling(pooled).view(B, num_chunks, D)

class ChunkDecoder(nn.Module):
    def __init__(self, d_model, chunk_size=16):
        super().__init__()
        self.chunk_size = chunk_size
        self.expander = nn.Linear(d_model, d_model*chunk_size)
        self.decoder = nn.TransformerDecoder(
            nn.TransformerDecoderLayer(d_model, 4, d_model*4, batch_first=True),
            num_layers=2
        )
        self.head = nn.Linear(d_model, 1)
    
    def forward(self, chunk_embs):
        B, N, D = chunk_embs.shape
        expanded = self.expander(chunk_embs).view(B*N, self.chunk_size, D)
        decoded = self.decoder(expanded, expanded)
        return self.head(decoded.view(B, N*self.chunk_size, D))

class HSTv4Unified(nn.Module):
    def __init__(self, d_model=32, chunk_size=16, num_layers=4):
        super().__init__()
        self.input = nn.Linear(1, d_model)
        self.chunk_encoder = ChunkEncoder(d_model, chunk_size)
        self.chunk_decoder = ChunkDecoder(d_model, chunk_size)
        self.transformer = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model, 4, d_model*4, batch_first=True),
            num_layers=num_layers
        )
        self.output = nn.Linear(d_model, 1)
    
    def forward(self, x, use_chunks=True):
        x = self.input(x.unsqueeze(-1) if len(x.shape)==2 else x)
        if use_chunks:
            chunk_embs = self.chunk_encoder(x)
            x = self.chunk_decoder(chunk_embs)
        else:
            x = self.transformer(x)
        return self.output(x)

data = np.array([np.linspace(0, 5, 100) + 2*np.sin(2*np.pi*np.arange(100)/50) + np.random.normal(0, 0.5, 100) for _ in range(1000)])
scaler = StandardScaler(); data = scaler.fit_transform(data.reshape(-1, 1)).reshape(data.shape)
train_loader = DataLoader(TensorDataset(torch.FloatTensor(data[:800]).to(device)), batch_size=32, shuffle=True)
val_loader = DataLoader(TensorDataset(torch.FloatTensor(data[800:]).to(device)), batch_size=32)

model = HSTv4Unified().to(device); opt = torch.optim.Adam(model.parameters(), 1e-3); crit = nn.MSELoss()
for e in range(10):
    for X, in train_loader:
        opt.zero_grad()
        loss = crit(model(X, use_chunks=True)[:, :-1], X[:, 1:])
        loss.backward(); opt.step()
    val_loss = sum(crit(model(X, use_chunks=True)[:, :-1], X[:, 1:]).item() for X, in val_loader) / len(val_loader)
    print(f"Epoch {e+1}: Val Loss={val_loss:.6f}")

torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v4_unified_models/hst_v4_unified_trained.pt')
print("✓ HST v4 Unified saved")
