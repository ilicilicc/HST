import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Plus,
  MessageSquare,
  Settings,
  LogOut,
  PanelLeftClose,
  PanelLeft
} from "lucide-react";
import { cn } from "@/lib/utils";
import logo from "@assets/white-b_1764606415571.png";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export function Sidebar() {
  const [location] = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const navItems = [
    { icon: MessageSquare, label: "Chat", href: "/" },
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: Settings, label: "Settings", href: "/settings" },
  ];

  return (
    <aside 
      className={cn(
        "h-screen bg-sidebar border-r border-sidebar-border flex flex-col fixed left-0 top-0 z-50 transition-all duration-300 ease-in-out",
        collapsed ? "w-16" : "w-72"
      )}
    >
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className={cn("flex items-center gap-3 overflow-hidden transition-all", collapsed ? "w-0 opacity-0" : "w-auto opacity-100")}>
           <div className="relative w-8 h-8 flex-shrink-0">
            <img 
              src={logo} 
              alt="Aethyr One" 
              className="w-full h-full object-contain"
            />
          </div>
          <span className="font-display font-bold text-lg tracking-wide whitespace-nowrap">AethyrHST</span>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setCollapsed(!collapsed)}
          className="text-muted-foreground hover:text-foreground"
        >
          {collapsed ? <PanelLeft size={18} /> : <PanelLeftClose size={18} />}
        </Button>
      </div>

      {/* New Chat Button */}
      <div className="px-3 mb-6">
        <Link href="/">
          <button className={cn(
            "flex items-center gap-3 w-full py-3 text-sidebar-foreground hover:bg-secondary/10 transition-all rounded-lg border border-sidebar-border group",
            collapsed ? "justify-center px-0" : "px-4"
          )}>
            <Plus size={18} className="text-primary group-hover:scale-110 transition-transform" />
            {!collapsed && <span className="text-sm font-medium">New Chat</span>}
          </button>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
        {!collapsed && <div className="px-4 py-2 text-xs font-medium text-muted-foreground/60 uppercase tracking-wider">Menu</div>}
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Tooltip key={item.href} delayDuration={0}>
              <TooltipTrigger asChild>
                <Link href={item.href} className={cn(
                  "flex items-center gap-3 py-2.5 rounded-lg transition-all duration-200 group cursor-pointer",
                  collapsed ? "justify-center px-0" : "px-4",
                  isActive 
                    ? "bg-secondary/20 text-primary" 
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/10"
                )}>
                    <item.icon 
                      size={20} 
                      className={cn(
                        "transition-colors flex-shrink-0",
                        isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                      )} 
                    />
                    {!collapsed && <span className="text-sm font-medium truncate">{item.label}</span>}
                </Link>
              </TooltipTrigger>
             {collapsed && <TooltipContent side="right">{item.label}</TooltipContent>}
            </Tooltip>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border/50">
        <div className={cn("flex items-center gap-3", collapsed ? "justify-center" : "")}>
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0">
            AO
          </div>
          {!collapsed && (
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium truncate">AethyrHST</p>
              <p className="text-xs text-muted-foreground truncate">Pro Plan</p>
            </div>
          )}
          {!collapsed && (
            <LogOut size={16} className="text-muted-foreground hover:text-destructive cursor-pointer" />
          )}
        </div>
      </div>
    </aside>
  );
}
