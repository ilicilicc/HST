import { Sidebar } from "./Sidebar";
import { Header } from "./Header";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex bg-background text-foreground font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col ml-16 md:ml-0 md:pl-16 lg:pl-0 transition-all duration-300">
        {/* Header is optional depending on the page, typically Grok/Claude don't have a persistent top header in chat view */}
        {/* We will keep it conditional or minimalist if needed, but for now let's remove the fixed margin shift to allow sidebar to overlay or push content dynamically */}
        <div className="flex-1 flex flex-col h-screen relative pl-0 lg:pl-72 transition-all duration-300 has-[aside.w-16]:lg:pl-16">
             {children}
        </div>
      </div>
    </div>
  );
}
