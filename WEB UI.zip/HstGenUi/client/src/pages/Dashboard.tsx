import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Code, Image as ImageIcon, FileText } from "lucide-react";
import { useStore } from "@/lib/store";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { templates, history } = useStore();

  return (
    <Layout>
      <div className="space-y-10 max-w-6xl mx-auto pt-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Dashboard
            </h1>
            <p className="text-muted-foreground text-lg">
              Manage your generative projects.
            </p>
          </div>
          <Link href="/generator">
            <Button size="lg" className="h-12 px-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg shadow-[0_0_20px_rgba(229,193,88,0.3)] transition-all text-base font-medium">
              <Sparkles className="w-5 h-5 mr-2" />
              New Generation
            </Button>
          </Link>
        </div>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-display font-semibold tracking-wide text-foreground">
              Templates
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {templates.map((template) => (
              <Link key={template.id} href={`/generator?template=${template.id}`}>
                <Card className="group hover:border-primary/50 transition-all cursor-pointer h-full bg-card border-border hover:shadow-[0_0_30px_rgba(229,193,88,0.1)]">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                      {template.icon === 'Feather' && <Sparkles className="w-6 h-6 text-primary" />}
                      {template.icon === 'Code' && <Code className="w-6 h-6 text-primary" />}
                      {template.icon === 'Image' && <ImageIcon className="w-6 h-6 text-primary" />}
                      {template.icon === 'FileText' && <FileText className="w-6 h-6 text-primary" />}
                    </div>
                    <CardTitle className="font-display text-lg">{template.title}</CardTitle>
                    <CardDescription className="text-sm line-clamp-2">
                      {template.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-display font-semibold tracking-wide text-foreground">
              Recent History
            </h2>
            <Button variant="link" className="text-primary hover:text-primary/80">
              View All <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
          
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            {history.map((entry, i) => (
              <div 
                key={entry.id}
                className={cn(
                  "flex items-center p-6 hover:bg-secondary/5 transition-colors group",
                  i !== history.length - 1 && "border-b border-border"
                )}
              >
                <div className="mr-6 p-3 rounded-lg bg-secondary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  {entry.type === 'text' && <FileText className="w-5 h-5" />}
                  {entry.type === 'code' && <Code className="w-5 h-5" />}
                  {entry.type === 'image' && <ImageIcon className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-base text-foreground mb-1 group-hover:text-primary transition-colors">
                    {entry.title}
                  </h3>
                  <p className="text-sm text-muted-foreground truncate font-mono">
                    {entry.preview}
                  </p>
                </div>
                <div className="ml-6 text-sm text-muted-foreground font-mono">
                  {entry.date}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
}
