import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send, Paperclip, Mic, Globe, Cpu } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useMutation, useQuery } from "@tanstack/react-query";
import logo from "@assets/white-b_1764606415571.png";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

interface Chat {
  id: string;
  title: string;
  createdAt: string;
}

export default function Generator() {
  const [prompt, setPrompt] = useState("");
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [model, setModel] = useState("aethyr-v1");
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [messages, prompt]);

  // Create new chat
  const createChatMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: `Chat ${new Date().toLocaleDateString()}` })
      });
      if (!response.ok) throw new Error('Failed to create chat');
      return response.json() as Promise<Chat>;
    },
    onSuccess: (chat) => {
      setCurrentChatId(chat.id);
      setMessages([]);
    }
  });

  // Load messages for current chat
  useEffect(() => {
    if (!currentChatId) return;
    
    setIsLoadingMessages(true);
    fetch(`/api/chats/${currentChatId}/messages`)
      .then(r => r.json())
      .then(data => {
        setMessages(data.map((msg: any) => ({
          ...msg,
          createdAt: new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        })));
      })
      .finally(() => setIsLoadingMessages(false));
  }, [currentChatId]);

  // Send message
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!currentChatId) throw new Error('No chat selected');
      
      const response = await fetch(`/api/chats/${currentChatId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'user', content })
      });
      if (!response.ok) throw new Error('Failed to send message');
      return response.json();
    },
    onSuccess: () => {
      // Reload messages after sending
      setTimeout(() => {
        if (currentChatId) {
          fetch(`/api/chats/${currentChatId}/messages`)
            .then(r => r.json())
            .then(data => {
              setMessages(data.map((msg: any) => ({
                ...msg,
                createdAt: new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              })));
            });
        }
      }, 500);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to send message" });
    }
  });

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    const messageContent = prompt;
    setPrompt("");

    if (!currentChatId) {
      try {
        // Create chat first
        const newChat = await createChatMutation.mutateAsync(undefined);
        setCurrentChatId(newChat.id);
        
        // Then send message
        await sendMessageMutation.mutateAsync(messageContent);
      } catch (error) {
        toast({ title: "Error", description: "Failed to create chat or send message" });
        setPrompt(messageContent);
      }
    } else {
      sendMessageMutation.mutate(messageContent);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleGenerate();
    }
  };

  const isEmpty = messages.length === 0;

  return (
    <Layout>
      <div className="flex flex-col h-full w-full relative bg-background">
        
        {/* Model Selector */}
        <div className="absolute top-4 right-6 z-20 flex items-center gap-2">
          <Select value={model} onValueChange={setModel}>
            <SelectTrigger className="w-[160px] h-9 bg-secondary/10 border-transparent hover:bg-secondary/20 transition-colors text-xs font-medium text-muted-foreground focus:ring-0">
              <div className="flex items-center gap-2">
                <Cpu size={14} className="text-primary" />
                <SelectValue />
              </div>
            </SelectTrigger>
            <SelectContent align="end">
              <SelectItem value="aethyr-v1">AethyrHST 1.0 (Fast)</SelectItem>
              <SelectItem value="aethyr-pro">AethyrHST Pro (Reasoning)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto w-full">
          {isEmpty ? (
            <div className="h-full flex flex-col items-center justify-center p-8 animate-in fade-in zoom-in duration-500">
              <div className="w-16 h-16 relative">
                <img src={logo} alt="Logo" className="w-full h-full object-contain" />
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto px-4 py-12 space-y-10 pb-40">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={cn(
                    "flex gap-6",
                    msg.role === 'user' ? "flex-row-reverse" : ""
                  )}
                >
                  <Avatar className={cn(
                    "h-8 w-8 mt-1",
                    msg.role === 'assistant' ? "bg-transparent" : "bg-secondary"
                  )}>
                    {msg.role === 'assistant' ? (
                      <img src={logo} alt="AI" className="w-full h-full object-contain p-1" />
                    ) : (
                      <AvatarFallback className="text-xs text-white bg-secondary">YOU</AvatarFallback>
                    )}
                  </Avatar>
                  
                  <div className={cn(
                    "flex flex-col gap-2 max-w-[85%]",
                    msg.role === 'user' ? "items-end" : "items-start"
                  )}>
                    <div className="whitespace-pre-wrap font-sans text-foreground/90 text-sm">
                      {msg.content}
                    </div>
                  </div>
                </div>
              ))}
              {sendMessageMutation.isPending && (
                <div className="flex gap-6 max-w-3xl mx-auto px-4">
                  <div className="w-8 h-8 flex items-center justify-center">
                    <img src={logo} alt="Loading" className="w-5 h-5 animate-pulse opacity-50" />
                  </div>
                  <div className="flex items-center gap-1 h-8">
                    <span className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce"></span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className={cn(
          "w-full px-4 transition-all duration-500 ease-in-out",
          isEmpty ? "absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-16 max-w-2xl" : "fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-xl border-t border-border/40 p-4 pl-0 lg:pl-72 has-[aside.w-16]:lg:pl-16"
        )}>
          <div className={cn(
            "mx-auto relative bg-card border border-border/50 shadow-lg transition-all duration-300",
            isEmpty ? "rounded-2xl" : "max-w-3xl rounded-xl mb-4"
          )}>
            <Textarea 
              ref={textareaRef}
              placeholder="Ask anything..." 
              className="w-full min-h-[56px] max-h-[200px] resize-none bg-transparent border-none focus-visible:ring-0 py-4 px-5 text-base placeholder:text-muted-foreground/40"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
              rows={1}
            />
            
            <div className="flex items-center justify-between p-3 pl-4">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground rounded-full hover:bg-secondary/10">
                  <Paperclip size={18} />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground rounded-full hover:bg-secondary/10">
                  <Mic size={18} />
                </Button>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary/10 rounded-full border border-transparent hover:border-border transition-all cursor-pointer group">
                  <Globe size={14} className="text-muted-foreground group-hover:text-primary transition-colors" />
                  <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground">Search</span>
                </div>
                <Button 
                  size="icon"
                  onClick={handleGenerate} 
                  disabled={!prompt.trim() || sendMessageMutation.isPending || createChatMutation.isPending}
                  className={cn(
                    "h-8 w-8 rounded-full transition-all duration-200",
                    !prompt.trim() ? "bg-secondary/20 text-muted-foreground" : "bg-primary text-primary-foreground"
                  )}
                >
                  <Send size={16} />
                </Button>
              </div>
            </div>
          </div>
          
          <p className="text-center text-[10px] text-muted-foreground/40 pb-2 mt-2">
            AI can make mistakes. Verify important information.
          </p>
        </div>

      </div>
    </Layout>
  );
}
