import { create } from 'zustand';

export type GenerationType = 'text' | 'image' | 'code';

export interface HistoryItem {
  id: string;
  title: string;
  type: GenerationType;
  preview: string;
  date: string;
}

export interface Template {
  id: string;
  title: string;
  description: string;
  icon: string;
  type: GenerationType;
}

interface AppState {
  history: HistoryItem[];
  templates: Template[];
  addHistory: (item: HistoryItem) => void;
}

export const useStore = create<AppState>((set) => ({
  history: [
    {
      id: '1',
      title: 'Cyberpunk City Description',
      type: 'text',
      preview: 'The neon rain slicked the streets of Neo-Tokyo...',
      date: '2 mins ago'
    },
    {
      id: '2',
      title: 'React Component Logic',
      type: 'code',
      preview: 'const useCybernetic = () => { ... }',
      date: '1 hour ago'
    },
    {
      id: '3',
      title: 'Orbital Station Concept',
      type: 'image',
      preview: ' orbital_station_v4.png',
      date: 'Yesterday'
    }
  ],
  templates: [
    {
      id: '1',
      title: 'Creative Writing',
      description: 'Generate immersive stories and descriptions',
      icon: 'Feather',
      type: 'text'
    },
    {
      id: '2',
      title: 'Code Assistant',
      description: 'Generate efficient, clean code snippets',
      icon: 'Code',
      type: 'code'
    },
    {
      id: '3',
      title: 'Visual Concept',
      description: 'Create stunning visual descriptions for art',
      icon: 'Image',
      type: 'image'
    },
    {
      id: '4',
      title: 'Technical Docs',
      description: 'Write clear technical documentation',
      icon: 'FileText',
      type: 'text'
    }
  ],
  addHistory: (item) => set((state) => ({ history: [item, ...state.history] }))
}));
